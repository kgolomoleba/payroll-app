# CPUT Payroll (UML → Code Starter)

School-compliant Java project using package root `za.ac.cput.payroll`.

## Contents
- Domain model (Employee, Job, Position, etc.)
- Service + Repository interfaces (with in-memory impls)
- PlantUML diagrams in `uml/`
- Dev container for GitHub Codespaces (Java 21 + PlantUML extensions)
- JUnit test

## Quick start (Codespaces)
1. Create a new **GitHub repository** (empty) and **create a Codespace** on it.
2. Upload this folder (or unzip it) into the root of the Codespace.
3. Run tests: `mvn -q -DskipTests=false test`
4. Open `.puml` files and press **Alt+D** to preview diagrams.

## Packages
- `za.ac.cput.payroll.domain.employee`
- `za.ac.cput.payroll.domain.job`
- `za.ac.cput.payroll.repository`
- `za.ac.cput.payroll.service`
